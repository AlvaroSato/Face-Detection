# Faster RCNN > 2023-05-24 12:00pm
https://universe.roboflow.com/face-detection-knahl/faster-rcnn-rpujr

Provided by a Roboflow user
License: Public Domain

