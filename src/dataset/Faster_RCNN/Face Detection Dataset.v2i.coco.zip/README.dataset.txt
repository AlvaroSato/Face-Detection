# Face Detection Dataset > 2023-05-11 6:35pm
https://universe.roboflow.com/face-detection-knahl/face-detection-dataset-vezee

Provided by a Roboflow user
License: Public Domain

