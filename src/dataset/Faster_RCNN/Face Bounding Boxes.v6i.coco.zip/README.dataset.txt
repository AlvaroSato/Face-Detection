# Face Bounding Boxes > 2023-05-24 4:02pm
https://universe.roboflow.com/face-detection-knahl/face-bounding-boxes

Provided by a Roboflow user
License: Public Domain

