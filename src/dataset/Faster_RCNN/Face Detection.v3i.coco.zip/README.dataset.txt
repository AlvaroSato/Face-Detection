# Face Detection > 2023-05-25 9:40am
https://universe.roboflow.com/face-detection-knahl/face-detection-zrzuk

Provided by a Roboflow user
License: Public Domain

